package com.masai.exception;

public class NoProductFoundInCart extends RuntimeException{

	public NoProductFoundInCart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoProductFoundInCart(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
