package com.masai.exception;

public class InvalidLoginKeyException extends RuntimeException {
	public InvalidLoginKeyException(String message) {
		super(message);
	}
} 
