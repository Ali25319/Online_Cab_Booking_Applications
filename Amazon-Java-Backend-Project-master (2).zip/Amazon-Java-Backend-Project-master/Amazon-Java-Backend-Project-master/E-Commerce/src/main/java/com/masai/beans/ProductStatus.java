package com.masai.beans;

public enum ProductStatus {
	AVAILABLE,
	UNAVAILABLE,
	OUT_OF_STOCK
}
