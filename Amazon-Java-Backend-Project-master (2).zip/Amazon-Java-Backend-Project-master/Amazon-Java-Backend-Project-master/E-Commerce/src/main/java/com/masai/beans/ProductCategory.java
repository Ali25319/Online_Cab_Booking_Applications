package com.masai.beans;


public enum ProductCategory {
	ELECTRONICS,
	BOOKS,
	CLOTHES
}
