package com.masai.beans;

public enum Status {
	SUCCESS,
	FAILED
}
