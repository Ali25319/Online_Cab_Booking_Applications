package com.masai.beans;

public enum DeliveryStatus {
	DELIVERED, IN_TRANSIT, OUT_FOR_DELIVERY
}
